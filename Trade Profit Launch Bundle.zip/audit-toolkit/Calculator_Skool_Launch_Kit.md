# Profit Calculator — Skool Launch Kit

Everything to get the calculator live and working as the hook in your free Skool group.

---

## 1. Get it live in 2 minutes (no coding)

The calculator is a single file: `trade-profit-calculator.html`. To turn it into a clickable link:

1. Go to **app.netlify.com/drop** (free, no account needed to start).
2. **Drag the HTML file** onto the page.
3. Netlify gives you a live URL instantly, e.g. `random-name-123.netlify.app`.
4. (Optional) Make a free account to rename it to something like `yourbusiness-profit.netlify.app`, or point your own domain at it.

That URL is what you paste into Skool. Done.

*Alternatives if you prefer: Vercel (drag-drop), GitHub Pages, or Cloudflare Pages — all free and all work the same way.*

---

## 2. Make it yours (edit 4 lines)

Open the HTML file in any text editor (Notepad, TextEdit, VS Code). Near the bottom, find the block marked **EDIT THESE 4 LINES** and change:

- **businessName** — your name / brand (shows top-left)
- **ctaHeadline** — the call-to-action heading
- **ctaText** — the call-to-action paragraph
- **bookingUrl** — where the button sends people. Use your **Skool group link**, a **Calendly**, or a simple booking form. This is how leads reach you.

Save, then re-upload to Netlify (drag the new file on, it replaces the old one).

---

## 3. Pinned Skool post (copy-paste)

Pin this in your community feed. Two angles — pick the one that fits your voice.

**Version A — the gut-punch**

> **Most tradies are quoting at a loss and have no idea.**
>
> Not because they're lazy — because nobody ever showed them what an hour *actually* costs once you count super, leave, workers comp, downtime and overheads.
>
> I built a free calculator that shows you your real break-even rate in about 60 seconds. Put your numbers in and see where you sit 👉 [LINK]
>
> Drop your break-even vs what you charge now in the comments. I'll tell you if you're leaving money on the table.

**Version B — the challenge**

> **Quick one: do you actually know your break-even hourly rate?**
>
> Not what you charge — what an hour *costs* you once leave, super, downtime and overheads are in. Most blokes are $20–30/hr under it without knowing.
>
> 60-second free tool here 👉 [LINK]
>
> Run yours and post the number. Bet half of us are quoting too low.

Replace `[LINK]` with your Netlify URL. The "post your number in the comments" line is doing real work — it drives engagement *and* surfaces exactly who needs an audit.

---

## 4. Loom walkthrough script (~3.5 min)

Record yourself screen-sharing the calculator. Embed the Loom in a Classroom lesson titled **"Why your $80/hr is actually losing money."** Skool plays Loom natively.

**[0:00 — Hook]**
"Quick one for you. If I asked what you charge an hour, you'd know. But if I asked what an hour *costs* you — most tradies can't answer that. And that gap is exactly where the money leaks out. Let me show you."

**[0:20 — The setup]**
"This is a free tool I built. I'll put in the numbers for a pretty typical one-man operation." → Enter wage, hours, weeks off, on-costs, overheads. Talk as you type: "Say I pay myself $40 an hour, work 38 hours, take six weeks off across the year…"

**[1:00 — The reveal]**
"Now watch. My break-even — what I have to charge just to *cover cost* — is over ninety bucks an hour. Not profit. Just to break even." → Point at the break-even number and the rate ladder. "And here's what a lot of blokes are charging." → Enter $85. "See that red line? It's *under* break-even. Every hour on the tools, this business is going backwards — about twelve grand a year."

**[1:40 — The apprentice twist]**
"Now here's where it gets interesting, because most of us aren't solo. Say I put on an apprentice — someone billable, on the tools." → Change 'on the tools' to 2. "Watch the break-even *drop*. Why? Because my ute, insurance and tools now get spread across two people's hours instead of one. A billable hand actually makes my numbers *better*."

**[2:15 — The office twist]**
"But watch what happens when I hire an office person — someone who *doesn't* bill, who just runs the books." → Enter $3,500 admin wages. "Break-even jumps straight back up. That admin wage has to be earned back by charging more. Same business, completely different rate — and most tradies never see this until it's hurting them."

**[2:55 — The why, quick]**
"The reason underneath all of it: you're paid for 38 hours but only *bill* maybe 28 once you count travel, quoting and admin. And everything the business owns comes out of those billable hours. Miss that, and you quote like an employee while you're carrying a whole business."

**[3:20 — The CTA]**
"Run your own numbers — link's below. Put your crew in. If your break-even comes up higher than you charge, that's your leak. And working it out properly — your rate, your apprentice's, your labourer's — is exactly what I do. Book a free Profit Review and I'll find it with you on your real jobs."

Keep it raw and on-site if you can — talking to camera from the ute beats a polished studio look for this audience. The apprentice-then-office sequence is the moment people share with their mates, so don't rush it.

---

## 5. How it all connects

```
Free tool (Netlify link)
        │  shows them the leak — the "oh no" moment
        ▼
Skool free group  ──►  pinned post + Loom lesson + "post your number"
        │  comments surface who's underpricing = your prospects
        ▼
Free 20-min Profit Review  (the CTA button)
        │  run their real job through the costing spreadsheet, live
        ▼
$750 Trade Profit Audit  ──►  hand over the Findings Report
        │
        ▼
$300–500/mo retainer  (keep their numbers right)
```

The calculator's only job is the first arrow: create the leak realisation. It shows the problem; you sell the fix. Don't over-explain the solution in the free tool — that's what the paid work is for.
