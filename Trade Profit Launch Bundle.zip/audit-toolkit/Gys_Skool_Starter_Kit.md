# Gys's Skool Starter Kit
### From resume to first paid client — without building a single course first

The mistake right now: you're trying to fill a Skool with content before you've sold anything. Flip it. **Sell one offer live → get paid → record what you delivered → *that* becomes your content.** You already have everything you need to start. Here's the build.

---

## 1. The offer: The Trade Profit Audit

> *"I'll show you exactly where you're losing money on every job — and rebuild your quoting so it stops."*

You audit a trade/construction business owner's quoting and job-costing, find the leaks, and rebuild their quote system. This is the one thing you sell. Nothing else, at first.

**Why this and not "business coaching" or "life coaching":**
- It solves an urgent, expensive, *measurable* problem (most tradies underquote and don't know it).
- It uses your unfair combo: forensic-audit brain + construction estimating + cost accounting + MD experience. Almost no one else can deliver this.
- The ROI is obvious in the sales conversation — "find the money you're losing" sells itself.
- You can deliver it **live, this month, with no pre-built material.**

**The price:**
- Start at **AUD $750** one-off for the audit + rebuilt quote template (2–3 live sessions).
- Once you've done 3–4 and have testimonials, raise to **$1,500**.
- Optional back-end: **$300–500/month** ongoing "pricing + numbers" retainer for the ones who want continued help.

**The maths that makes "fast money" real:** 3 audits at $750 = $2,250 this month. That's not a membership grind. That's three conversations and three deliveries.

---

## 2. Your positioning (the words you actually use)

This is your Skool "About" paragraph, your sales-call opener, and your social bio. Lead with the operator + owner credibility your resume proves — not "trade assistant."

> *"I ran civil and concrete on some of the biggest construction projects in the world, and I owned and managed my own business for eight years. I've quoted, costed, and delivered jobs where being wrong on the numbers cost real money. Now I help trade and construction business owners fix the one thing quietly killing their profit: how they price and quote their work. I find the money you're losing — and I rebuild your system so you stop losing it."*

That's true, it's specific, and it beats every 25-year-old "agency guru" in the Skool ecosystem.

---

## 3. How the Skool fits around this

Your Skool is **not** the product. It's the trust engine that finds buyers and warms them up. Run it **free**.

- **Free group** = top of funnel. Costs you almost nothing in fees because no money changes hands there.
- **The paid offer** = sold in DMs / on a call, off-platform or via Skool's payment, your choice.
- Later, once you've delivered a few audits, the **recordings become a Classroom course** inside the group — now it has real material, built from real work.

**What to post in the free group (3 posts a week, 10 min each):**
1. One pricing mistake tradies make (e.g. "markup vs margin — why 20% markup is NOT 20% profit").
2. One real-world cost most tradies forget to price (labour burden, travel, equipment, waste, rework, overhead).
3. One "before/after" or quick win from an audit (anonymised).

That's your whole content strategy. You're not teaching everything — you're proving you see what they're missing.

---

## 4. The live delivery script (this IS your material)

You don't need slides. You need this run-sheet. Deliver over Zoom.

**Session 1 — Find the leak (60 min)**
- Have them bring their last 5 quotes + what those jobs *actually* cost them.
- Compare quoted vs actual. The gap is the leak. Almost always it's in:
  - Labour costed at bare wage, not true burden (super, leave, tools, downtime).
  - Materials with no waste/wastage factor.
  - Travel, equipment, and small consumables not priced at all.
  - **Markup confused with margin** (the silent killer).
  - No overhead recovery — they price jobs but never their business running costs.
  - Margin too thin or guessed, not set.

**Session 2 — Rebuild the quote (60 min)**
- Build them a simple cost-plus quote template: true labour rate → materials + waste → equipment/travel → overhead recovery → target margin.
- Set their numbers *with* them so they own it.

**Session 3 — Hand over + lock in (30 min)**
- Walk them through using the template on their next real quote.
- Offer the monthly retainer for ongoing support.
- **Ask for a testimonial and a referral.** Every time.

This is repeatable for every client. After 3 of these, you've got a recordable, sellable system.

---

## 5. Getting the first 5–10 people (no audience needed)

You don't need followers. You need a few conversations.

1. **Your own network first.** You know tradies, sparkies, builders, subbies from Maritimo, Ozzie Electrical, your own jobs. Message 10 of them: *"I'm helping trade business owners find where they're losing money on quoting. Doing a few free 20-min reviews to start — want one?"* Free reviews → paid audits.
2. **Local Facebook trade groups + Gold Coast tradie groups.** Post one genuinely useful pricing tip a week. Soft-mention you do reviews.
3. **The free Skool** as the place you send anyone who's interested, so they stick around and warm up.
4. **Offer 2–3 free audits up front** in exchange for a testimonial. Those testimonials are what let you charge $750, then $1,500.

---

## 6. Your first 7 days (do exactly this)

- **Day 1:** Rewrite your Skool name + About using the positioning above. Set the group to free.
- **Day 2:** Write the offer down as a one-pager (use Section 1). Decide your start price: $750.
- **Day 3:** Message 10 people from your network offering a free 20-min quote review.
- **Day 4:** Post your first value post in the group + one trade Facebook group.
- **Day 5:** Run your first free review. Use the Session 1 script. At the end: *"I can fix this properly — that's the paid audit."*
- **Day 6:** Post the win (anonymised) from Day 5.
- **Day 7:** Follow up everyone who showed interest. Book one paid audit.

**Goal for month 1:** not a full course, not 100 members. One paid audit. Then two. The rest compounds from there.

---

### The one rule
Don't build anything you haven't sold yet. Sell the audit → deliver it live → record it → *now* you have material. You're not short on knowledge. You were just building in the wrong order.
